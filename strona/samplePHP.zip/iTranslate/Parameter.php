<?php

class iTranslate_Parameter extends iTranslate_Parameter_Abstract {
    
}