<?php

interface iTranslate_Translate_Domain {
    const DOM_GENERAL = "general";
    const DOM_ART = "art";
    const DOM_LAW = "law";
    const DOM_SCI = "sci";
    const DOM_TECH = "tech";
    const DOM_INFO = "info";
    const DOM_TEL = "tel";
    const DOM_BIO = "bio";
    const DOM_ECO = "eco";
    const DOM_AGR = "agr";
    const DOM_TRAVEL = "travel";
    const DOM_MIL = "mil";
    const DOM_SPORT = "sport";
}