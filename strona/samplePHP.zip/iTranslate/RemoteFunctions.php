<?php

abstract class iTranslate_RemoteFunctions {
    const FNC_GETLANGUAGES = "GetLanguages";
    const FNC_GETROUTES = "GetRoutes";
    const FNC_GETPROVIDERS = "GetProviders";
    const FNC_TRANSLATE = "Translate";
}