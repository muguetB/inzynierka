<?php

class iTranslate_Response_Languages {
    
    /**
     * Source languages
     * @var array 
     */
    public $src = array();
    
    /**
     * Target languages
     * @var array 
     */
    public $trg = array();
    
    /**
     * Ignored languages
     * @var array 
     */
    public $exclude = array();
    
}