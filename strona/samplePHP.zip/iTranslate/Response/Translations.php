<?php

class iTranslate_Response_Translations {
    
    /**
     * Data
     * @var iTranslate_Response_Translation_Object[]
     */
    public $dat = array();
}