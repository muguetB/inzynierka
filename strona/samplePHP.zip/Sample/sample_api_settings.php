<?php

/**
 * Settings for the api 
 */
$apiSettings = array(
    'apiKey' => 'xxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
    'cacheFolder' => 'cache'
);