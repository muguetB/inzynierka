Pliki skórki/templatki dla Wordpress z użyciem Twitter Bootstrap
---

Zapraszam do zapoznania się z kursem tworzenia własnych skórek dla Wordpress na stronie
[http://wordpress.kursbootstrap.pl][1]

Uaktualniana na bieżąco przykładowa strona z kursu
[http://example.kursbootstrap.pl][2]

[1]: http://wordpress.kursbootstrap.pl
[2]: http://example.kursbootstrap.pl