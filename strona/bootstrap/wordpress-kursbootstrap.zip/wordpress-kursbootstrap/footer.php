<!-- Templatka wyglądu stopki-->

  <footer id="footer">
    <div class="container">
      <div class="row">
        <!--Dolne menu strony -->
          <!--<div class="navbar">
          <div class="navbar-inner">
            <?php 
              //wp_nav_menu( array(
              //'theme_location'  =>  'footer-nav',
              //'container_class' =>  false, 
              //menu_class'      =>  'nav'
              //) );
            ?>
          </div>
        </div> -->
        
        <!--Treść stopki-->
        <div class="col-md-12">
          <div class="well">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim, quaerat nam dicta dolor sunt veritatis modi obcaecati accusamus inventore quos laborum harum quasi iusto commodi autem rerum quod cupiditate ipsum.</div>
        </div>
        
      </div>
    </div>    
  </footer>  
  <?php wp_footer();?>
  </body>
</html>