<?php 
/*
* Default header file
*/
?>

<!-- Templatka wyglądu nagłówka-->

<!DOCTYPE html>
<html>
  <head>
    <title>Moja pierwsza strona oparta na Wordpress i Bootstrap</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head();?>
  </head>
  <body>
    <!-- Treść nagłówka strony -->
      <header>
        <div class="container">
          <div class="row">
            <div class="col-md-12">
		          <nav class="navbar navbar-default no-corners navbar-clear" role="navigation">
                <div class="container-fluid">
                  <!-- Brand and toggle get grouped for better mobile display -->
                  <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                      <span class="sr-only">Nawigacja strony</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php bloginfo('url'); ?>">LOGOTYP</a>
<!--
                    <span class="navbar-text"><i class="fa fa-phone fa-3x" style="vertical-align: middle;"></i><a href="+48600600600"></a> 600600600</span>
                    <span class="navbar-text"><i class="fa fa-envelope-o fa-3x" style="vertical-align: middle;"></i> moj-adres@email.pl</span>
-->
                  </div>
                  <!-- Collect the nav links, forms, and other content for toggling -->
                  <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <!--Generowanie Górnego Menu Strony-->
                    <?php 
                      wp_nav_menu( array(
                        'menu'            => 'main-nav',
                        'menu_class'      => 'nav navbar-nav navbar-right',
                        'depth' => 2,
                        // 'link_before'     => '<b>',
                        // 'link_after'      => '</b>',
                        'walker'   => new BootstrapNavMenuWalker()
                      ));
                    ?>
                  </div><!-- /.navbar-collapse -->
                </div><!-- end container fluid -->
              </nav> <!-- end navbar -->
          </div>
        </div>
      </header>
<!-- end of header -->
