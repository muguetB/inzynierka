<!--Uruchomienie wyświetlania panelu bocznego-->
<?php dynamic_sidebar('main-sidebar'); ?>

<!--Własny element w panelu bocznym-->
<div class="col-md-12">
  <div class="panel panel-info no-corners">
    <div class="panel-heading"><h3 class="panel-title">Własny element</h3></div>
    <div class="panel-body">
      <p>Panel boczny z własną treścią</p>
    </div>
  </div>
</div> 